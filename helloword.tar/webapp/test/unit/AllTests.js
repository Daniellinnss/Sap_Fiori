sap.ui.define([
	"helloword/test/unit/controller/Hello_View.controller"
], function () {
	"use strict";
});
